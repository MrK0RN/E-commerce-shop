<?php
//ini_set('display_errors', '0');
session_start();
if (!isset($_SESSION["auth"])){
	var_dump("htrenrj");
	echo "<script>window.location.href = 'login.php';</script>";
	exit();
}
if ($_SESSION["auth"] != True){
	var_dump("jtjvnjfdvd");
	echo "<script>window.location.href = 'login.php';</script>";
}
?>

