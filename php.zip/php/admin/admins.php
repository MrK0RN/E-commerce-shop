<?php
include "auth.php";
$title = "Админы";

include "template/admins.php";
include "template.php";
?>