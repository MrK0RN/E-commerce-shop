<?php
include "auth.php";
$title = "Социальные сети";

include "template/socNetworks.php";
include "template.php";
?>
