<?php
include "auth.php";
$title = "Верхняя навигационная панель";

include "template/navHeader.php";
include "template.php";
?>
