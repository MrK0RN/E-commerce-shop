<?php
include "auth.php";
$title = "Заказы";

include "template/orders.php";
include "template.php";
?>