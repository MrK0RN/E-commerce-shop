<?php
include "auth.php";
$title = "Каталог товаров";

include "template/goods.php";
include "template.php";
?>