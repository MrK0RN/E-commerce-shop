<?php

echo "<header>
	<div class='header'>
		<h1>".$title."</h1>
		<div class='user-info'>
			<img src='https://ui-avatars.com/api/?name=Admin&background=2c3e50&color=fff' alt='Admin'>
			<div>
				<div>Администратор</div>
				<!--<small>Последний вход: 15.05.2023 14:30</small>-->
			</div>
		</div>
	</div>
</header>";
?>

