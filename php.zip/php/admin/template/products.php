<?php

$main = '';
$table_name = "cards";
$add = true;
$edit = true;
$delete = true;
$buttons = ["Редактировать фото" => "assets/add_cards_photo.php"];
include "assets/tables.php";
$main .= $text2;
?>