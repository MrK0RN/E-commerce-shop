<?php
$main = "
<div class='stats-container'>
	<div class='stat-card users'>
		<i class='fas fa-users'></i>
		<h3>Пользователи</h3>
		<div class='value'>1 248</div>
		<!--<small>+5% за месяц</small>-->
	</div>
	
	<div class='stat-card products'>
		<i class='fas fa-boxes'></i>
		<h3>Товары</h3>
		<div class='value'>576</div>
		<!--<small>+12 новых</small>-->
	</div>
	
	<div class='stat-card orders'>
		<i class='fas fa-shopping-cart'></i>
		<h3>Новые заказы</h3>
		<div class='value'>23</div>
		<!--<small>Требуют обработки</small>-->
	</div>
	<!--
	<div class='stat-card revenue'>
		<i class='fas fa-dollar-sign'></i>
		<h3>Доход</h3>
		<div class='value'>124 560 ₽</div>
		<small>За текущий месяц</small>
	</div>-->
</div>";
?>