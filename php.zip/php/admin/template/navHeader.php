<?php
$table_name = "navHeader";
$add = true;
$edit = true;
$delete = true;
include "assets/tables.php";

$main .= $text2;
?>
