<?php

//$responce, $add_src, $edit, $delete
$table_name = "admins";
$edit = true;
$add = true;
$delete = false;
include "assets/tables.php";
$main = $text2;
?>
