<?php
include "auth.php";
$title = "Контакты";

include "template/contacts.php";
include "template.php";
?>
