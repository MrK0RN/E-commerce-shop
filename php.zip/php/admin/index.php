<?php
$title = "Главная";

include "template/index.php";
include "template.php";
?>