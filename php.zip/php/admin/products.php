<?php
include "auth.php";
$title = "Подробные карточки товаров";

include "template/products.php";
include "template.php";
?>