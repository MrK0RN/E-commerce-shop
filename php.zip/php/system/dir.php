<?php
$logs = "/var/www/html/system/logs.txt";
$dir = "/var/www/html/system/all.sql";
?>